var express = require("express");
var app = express();
var bodyParser = require("body-parser");

app.use(express.static(__dirname+"/public"));
app.set("view engine", "ejs");

app.use(bodyParser());

app.get("/", function(req,res){
    res.render("login");
});
app.post("/", function(req,res){
 var obj=req.body;
 if(obj.email!="admin"){
    console.log("User ID is incorrect");
 }
 else{
     if(obj.password=="123"){
         console.log("Login Successfull");
     }
     else{
        console.log("User ID and password is incorrect");
     }
 }
});
app.listen(3000,function(){
    console.log("Server Running...");
})